# SQL Scripts for Maria DB

- for Maria DB just download and setup without changing the default settings
- after that just execute .sql scripts from " DBeaver " or " cmd " to create required tables and columns