module.exports = {
    USER: 0,
    ALL: 1
}