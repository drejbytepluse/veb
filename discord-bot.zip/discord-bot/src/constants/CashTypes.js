module.exports = {
    CASH: "cash",
    BANK: "bank"
}