# Blockman Forge Discord Bot
Mainly compatible with Blockman Forge

## Global TODOs
Empty
